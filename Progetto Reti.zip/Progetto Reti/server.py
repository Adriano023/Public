import socket  # Importa il modulo socket per la comunicazione di rete.
import threading  # Importa il modulo threading per gestire le connessioni dei client in parallelo.
import json  # Importa il modulo json per la serializzazione e deserializzazione dei dati.
import os  # Importa il modulo os per interagire con il sistema operativo.

class UniversityServer:
    def __init__(self, host='localhost', port=10000):
        # Inizializza il server con l'host e la porta specificati.
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Crea un socket TCP/IP.
        self.server_socket.bind((self.host, self.port))  # Associa il socket all'host e alla porta.
        self.server_socket.listen(5)  # Mette il server in ascolto per le connessioni in entrata.
        print(f"Server listening on {self.host}:{self.port}")  # Stampa l'indirizzo e la porta del server.

    def handle_client_connection(self, client_socket):
        # Gestisce la connessione con un client.
        while True:
            try:
                request = client_socket.recv(1024).decode('utf-8')  # Riceve la richiesta dal client.
                if not request:
                    break  # Interrompe il ciclo se la connessione è chiusa dal client.
                
                request_data = json.loads(request)  # Deserializza la richiesta da JSON a un oggetto Python.
                response_data = self.process_request(request_data)  # Elabora la richiesta e ottiene la risposta.
                client_socket.sendall(json.dumps(response_data).encode('utf-8'))  # Invia la risposta al client.
            except Exception as e:
                print(f"Error: {e}")  # Stampa eventuali errori.
                break
        client_socket.close()  # Chiude la connessione con il client.

    def process_request(self, request):
        # Elabora la richiesta del client e restituisce una risposta.
        try:
            if 'type' not in request:
                return {'error': 'Request type is missing'}  # Restituisce un errore se il tipo di richiesta non è specificato.

            # Gestisce i diversi tipi di richieste in base al campo 'type'.
            if request['type'] == 'add_exam':
                return self.add_exam(request['exam_name'], request['dates'])
            elif request['type'] == 'book_exam':
                return self.book_exam(request['student_id'], request['exam_name'], request['date'])
            elif request['type'] == 'get_exam_dates':
                return self.get_exam_dates(request['exam_name'])
            elif request['type'] == 'get_all_exams':
                return self.get_all_exams()
            else:
                return {'error': 'Invalid request type'}  # Restituisce un errore se il tipo di richiesta non è valido.
        except Exception as e:
            return {'error': f'An unexpected error occurred: {str(e)}'}  # Gestisce eventuali eccezioni non previste.

    def load_or_create_json(self, filename):
        # Carica un file JSON o crea una lista vuota se il file non esiste.
        try:
            with open(filename, 'r') as f:
                return json.load(f)  # Carica i dati dal file JSON.
        except (FileNotFoundError, json.JSONDecodeError):
            return []  # Restituisce una lista vuota se il file non esiste o contiene JSON non valido.

    def add_exam(self, exam_name, new_date):
        # Aggiunge un nuovo esame o una nuova data a un esame esistente.
        exams = self.load_or_create_json('exams.json')  # Carica gli esami esistenti.
        exam_found = False

        # Cerca l'esame nella lista e aggiunge la nuova data se non presente.
        for exam in exams:
            if exam['exam_name'] == exam_name:
                exam_found = True
                if new_date not in exam['dates']:
                    exam['dates'].append(new_date)  # Aggiunge la nuova data.
                    exam['dates'] = sorted(exam['dates'])  # Ordina le date.
                break

        # Se l'esame non è stato trovato, lo aggiunge alla lista.
        if not exam_found:
            exams.append({'exam_name': exam_name, 'dates': [new_date]})

        # Salva gli esami aggiornati nel file JSON.
        with open('exams.json', 'w') as f:
            json.dump(exams, f, indent=4)

        return {'success': f'Exam {exam_name} updated/added successfully with new date {new_date}.'}

    def book_exam(self, student_id, exam_name, date):
        # Prenota un esame per uno studente.
        exams = self.load_or_create_json('exams.json')  # Carica gli esami esistenti.
        bookings = self.load_or_create_json('booking.json')  # Carica le prenotazioni esistenti.

        # Verifica se l'esame esiste e se la data è valida.
        exam_exists = any(exam for exam in exams if exam['exam_name'] == exam_name and date in exam.get('dates', []))
        if not exam_exists:
            return {'error': 'Exam does not exist or date is invalid'}

        # Verifica se lo studente ha già prenotato l'esame per quella data.
        booking_exists = any(booking for booking in bookings if booking['student_id'] == student_id and booking['exam_name'] == exam_name and booking['date'] == date)
        if booking_exists:
            return {'error': f'Student {student_id} is already booked for exam {exam_name} on {date}'}

        # Trova il numero di prenotazione più alto per l'esame e assegna il successivo.
        last_booking_number = max([booking.get('booking_number', 0) for booking in bookings if booking['exam_name'] == exam_name], default=0)
        new_booking = {
            'student_id': student_id,
            'exam_name': exam_name,
            'date': date,
            'booking_number': last_booking_number + 1
        }

        # Aggiunge la nuova prenotazione e salva nel file JSON.
        bookings.append(new_booking)
        with open('booking.json', 'w') as f:
            json.dump(bookings, f, indent=4)

        return {'success': 'Booking made successfully', 'booking_number': new_booking['booking_number']}

    def get_exam_dates(self, exam_name):
        # Restituisce le date disponibili per un esame specifico.
        exams = self.load_or_create_json('exams.json')
        for exam in exams:
            if exam['exam_name'] == exam_name:
                return {'success': True, 'dates': exam.get('dates', [])}
        return {'error': 'Exam not found'}

    def get_all_exams(self):
        # Restituisce tutti gli esami disponibili.
        exams = self.load_or_create_json('exams.json')
        if exams:
            return {'exams': exams}
        else:
            return {'error': 'No exams available'}

    def start(self):
        # Avvia il server e ascolta per connessioni in entrata.
        print("Starting the server...")
        while True:
            client_sock, address = self.server_socket.accept()  # Accetta una nuova connessione.
            print(f"Accepted connection from {address}")  # Stampa l'indirizzo del client connesso.
            # Crea un nuovo thread per gestire la connessione del client.
            client_handler = threading.Thread(target=self.handle_client_connection, args=(client_sock,))
            client_handler.start()  # Avvia il thread.

if __name__ == "__main__":
    # Se il file è eseguito direttamente, avvia il server.
    server = UniversityServer()
    server.start()
