import socket  # Importa il modulo socket per le comunicazioni di rete
import threading  # Importa il modulo threading per eseguire operazioni parallele
import json  # Importa il modulo json per serializzare/deserializzare dati in formato JSON

class SecretaryServer:
    def __init__(self, host='localhost', port=10001, uni_server_host='localhost', uni_server_port=10000):
        # Inizializza il SecretaryServer con indirizzi e porte per il proprio server e per il server universitario
        self.host = host  # Host del server della segreteria
        self.port = port  # Porta del server della segreteria
        self.uni_server_host = uni_server_host  # Host del server universitario
        self.uni_server_port = uni_server_port  # Porta del server universitario
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Crea un socket TCP/IP
        self.server_socket.bind((self.host, self.port))  # Associa il socket all'indirizzo e alla porta
        self.server_socket.listen(5)  # Mette il server in ascolto per connessioni in entrata
        print(f"Secretary Server listening on {self.host}:{self.port}")  # Stampa che il server è in ascolto

    def handle_student_connection(self, client_socket):
        # Gestisce la connessione in entrata da uno studente
        try:
            while True:
                request = client_socket.recv(1024).decode('utf-8')  # Riceve la richiesta dallo studente
                if not request:
                    break  # Se non c'è richiesta, interrompe il ciclo
                request_data = json.loads(request)  # Deserializza la richiesta da JSON a dizionario
                # Inoltra la richiesta al server universitario e ottiene la risposta
                uni_response = self.forward_request_to_university_server(request_data)
                # Invia la risposta al client (studente) in formato JSON
                client_socket.sendall(json.dumps(uni_response).encode('utf-8'))
        finally:
            client_socket.close()  # Chiude la connessione con lo studente

    def forward_request_to_university_server(self, request_data):
        # Inoltra la richiesta ricevuta allo studente al server universitario e ritorna la risposta
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as uni_socket:  # Crea un socket temporaneo
            uni_socket.connect((self.uni_server_host, self.uni_server_port))  # Si connette al server universitario
            uni_socket.sendall(json.dumps(request_data).encode('utf-8'))  # Invia la richiesta al server universitario
            response = uni_socket.recv(1024).decode('utf-8')  # Riceve la risposta dal server universitario
            return json.loads(response)  # Deserializza la risposta da JSON a dizionario e la ritorna

    def start(self):
        # Avvia il server della segreteria e rimane in ascolto per connessioni in entrata
        while True:
            client_sock, _ = self.server_socket.accept()  # Accetta una nuova connessione
            print("Accepted connection from student")  # Stampa che una nuova connessione è stata accettata
            # Crea un nuovo thread per gestire la connessione in modo che il server possa servire più studenti contemporaneamente
            client_handler = threading.Thread(target=self.handle_student_connection, args=(client_sock,))
            client_handler.start()  # Avvia il thread

if __name__ == "__main__":
    secretary_server = SecretaryServer()
    secretary_server.start()  # Avvia il server della segreteria
