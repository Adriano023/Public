import socket  # Importa il modulo socket per le comunicazioni di rete
import json  # Importa il modulo json per serializzare e deserializzare i dati in formato JSON
import tkinter as tk  # Importa il modulo tkinter per creare l'interfaccia grafica
from tkinter import messagebox  # Importa messagebox da tkinter per mostrare finestre di dialogo
from tkcalendar import Calendar  # Importa Calendar da tkcalendar per mostrare un widget calendario
from tkinter import simpledialog  # Importa simpledialog da tkinter per richiedere input all'utente

class SecretaryClient:
    def __init__(self, server_host='localhost', server_port=10000):
        # Inizializza il client della segreteria con l'host e la porta del server
        self.server_host = server_host
        self.server_port = server_port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Crea un socket TCP/IP

    def connect_to_server(self):
        # Tenta di connettersi al server; in caso di errore, stampa un messaggio e termina il programma
        try:
            self.client_socket.connect((self.server_host, self.server_port))
            print("Connected to the University Server.")
        except ConnectionRefusedError:
            print("Failed to connect to the University Server.")
            exit()

    def add_exam(self, exam_name, date):
        # Invia una richiesta al server per aggiungere un nuovo esame con nome e data specificati
        request = {'type': 'add_exam', 'exam_name': exam_name, 'dates': date}
        self.client_socket.sendall(json.dumps(request).encode('utf-8'))
        response = self.client_socket.recv(1024).decode('utf-8')
        return json.loads(response)

    def close_connection(self):
        # Chiude la connessione con il server
        self.client_socket.close()

    def book_exam_for_student(self, student_id, exam_name, date):
        # Invia una richiesta al server per prenotare un esame per uno studente
        request = {'type': 'book_exam', 'student_id': student_id, 'exam_name': exam_name, 'date': date}
        self.client_socket.sendall(json.dumps(request).encode('utf-8'))
        response = self.client_socket.recv(1024).decode('utf-8')
        return json.loads(response)

    def get_exam_dates(self, exam_name):
        # Richiede al server le date disponibili per un esame specifico
        request = {'type': 'get_exam_dates', 'exam_name': exam_name}
        self.client_socket.sendall(json.dumps(request).encode('utf-8'))
        response = self.client_socket.recv(1024).decode('utf-8')
        return json.loads(response)

    def get_all_exams(self):
        # Richiede al server un elenco di tutti gli esami disponibili
        request = {'type': 'get_all_exams'}
        self.client_socket.sendall(json.dumps(request).encode('utf-8'))
        response = self.client_socket.recv(1024).decode('utf-8')
        return json.loads(response)

class SecretaryGUI:
    def __init__(self, secretary_client):
        # Inizializza l'interfaccia grafica della segreteria con un client della segreteria
        self.secretary_client = secretary_client
        self.root = tk.Tk()  # Crea la finestra principale
        self.root.title("Secretary Interface")  # Imposta il titolo della finestra

        # Crea e imballa i widget per l'input del nome dell'esame
        tk.Label(self.root, text="Exam Name:").pack()
        self.exam_name_entry = tk.Entry(self.root)
        self.exam_name_entry.pack()

        # Crea e imballa i widget per l'input della data dell'esame
        tk.Label(self.root, text="Exam Date:").pack()
        self.exam_date_entry = tk.Entry(self.root, state='readonly')
        self.exam_date_entry.pack()

        # Crea e imballa il bottone per mostrare il calendario e selezionare una data
        tk.Button(self.root, text="Select Date", command=self.show_calendar).pack()
        # Crea e imballa il bottone per aggiungere un esame
        tk.Button(self.root, text="Add Exam", command=self.add_exam).pack()

        # Crea e imballa il bottone per prenotare un esame per uno studente
        tk.Button(self.root, text="Book Exam for Student", command=self.book_exam_for_student).pack()
        # Crea e imballa il bottone per mostrare le date disponibili di un esame
        tk.Button(self.root, text="Show Available Exam Dates", command=self.show_available_exam_dates).pack()
        # Crea e imballa il bottone per mostrare tutti gli esami disponibili
        tk.Button(self.root, text="Show All Exams", command=self.show_all_exams).pack()

    def show_calendar(self):
        # Mostra il widget calendario per selezionare una data
        top = tk.Toplevel(self.root)  # Crea una nuova finestra di dialogo
        cal = Calendar(top, selectmode='day', date_pattern='yyyy-mm-dd')  # Crea il calendario
        cal.pack(pady=20)  # Imballa il calendario nella finestra di dialogo

        def on_date_select():
            # Funzione chiamata quando una data è selezionata
            date = cal.get_date()  # Ottiene la data selezionata
            self.exam_date_entry.config(state=tk.NORMAL)  # Rende scrivibile l'entry della data
            self.exam_date_entry.delete(0, tk.END)  # Cancella il contenuto attuale
            self.exam_date_entry.insert(0, date)  # Inserisce la data selezionata
            self.exam_date_entry.config(state='readonly')  # Rimette l'entry in stato readonly
            top.destroy()  # Chiude la finestra di dialogo

        tk.Button(top, text="Select", command=on_date_select).pack()  # Crea e imballa il bottone per selezionare la data

    def add_exam(self):
        # Invia una richiesta al server per aggiungere un nuovo esame
        exam_name = self.exam_name_entry.get()  # Ottiene il nome dell'esame dall'entry
        exam_date = self.exam_date_entry.get()  # Ottiene la data dell'esame dall'entry

        # Controlla se la data è vuota
        if not exam_date.strip():
            messagebox.showerror("Error", "The exam date cannot be empty.")  # Mostra un messaggio di errore
            return  # Interrompe l'esecuzione del metodo

        # Procede con l'invio della richiesta al server se la data non è vuota
        response = self.secretary_client.add_exam(exam_name, exam_date)  # Invia la richiesta e ottiene la risposta
        if 'success' in response:  # Se la risposta indica successo
            messagebox.showinfo("Success", response['success'])  # Mostra un messaggio di successo
        elif 'error' in response:  # Se la risposta indica un errore
            messagebox.showerror("Error", response['error'])  # Mostra un messaggio di errore

    def book_exam_for_student(self):
        # Permette di prenotare un esame per uno studente
        student_id = simpledialog.askstring("Input", "Student ID:", parent=self.root)  # Richiede l'ID dello studente
        exam_name = simpledialog.askstring("Input", "Exam Name:", parent=self.root)  # Richiede il nome dell'esame
        date = simpledialog.askstring("Input", "Exam Date (YYYY-MM-DD):", parent=self.root)  # Richiede la data dell'esame
        response = self.secretary_client.book_exam_for_student(student_id, exam_name, date)  # Invia la richiesta e ottiene la risposta
        messagebox.showinfo("Response", response.get('success', response.get('error', 'Unknown error')))  # Mostra la risposta

    def show_available_exam_dates(self):
        # Mostra le date disponibili per un esame
        exam_name = simpledialog.askstring("Input", "Exam Name:", parent=self.root)  # Richiede il nome dell'esame
        response = self.secretary_client.get_exam_dates(exam_name)  # Ottiene le date disponibili
        print(response)  # Stampa la risposta per debug
        dates = response.get('dates')  # Estrae le date dalla risposta
        if dates:  # Se ci sono date disponibili
            messagebox.showinfo("Available Dates", "\n".join(dates))  # Mostra le date in una messagebox
        else:  # Se non ci sono date disponibili o si è verificato un errore
            messagebox.showinfo("Available Dates", response.get('error', 'No dates available or exam does not exist'))  # Mostra un messaggio appropriato

    def show_all_exams(self):
        # Mostra tutti gli esami disponibili
        response = self.secretary_client.get_all_exams()  # Ottiene tutti gli esami
        exams = response.get('exams')  # Estrae gli esami dalla risposta
        if exams:  # Se ci sono esami disponibili
            exams_str = "\n".join([f"{exam['exam_name']}: {', '.join(exam['dates'])}" for exam in exams])  # Formatta gli esami in una stringa
            messagebox.showinfo("All Exams", exams_str)  # Mostra gli esami in una messagebox
        else:  # Se non ci sono esami disponibili
            messagebox.showinfo("All Exams", "No exams available")  # Mostra un messaggio di errore

    def run(self):
        # Avvia l'interfaccia grafica
        self.root.mainloop()  # Entra nel loop principale di Tkinter

if __name__ == "__main__":
    secretary_client = SecretaryClient()  # Crea un'istanza del SecretaryClient
    secretary_client.connect_to_server()  # Connette il SecretaryClient al server
    gui = SecretaryGUI(secretary_client)  # Crea l'interfaccia grafica passando il SecretaryClient
    gui.run()  # Avvia l'interfaccia grafica
