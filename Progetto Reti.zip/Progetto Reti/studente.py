import socket  # Importa il modulo socket per la comunicazione di rete
import json  # Importa il modulo json per serializzare/deserializzare dati in formato JSON
import tkinter as tk  # Importa il modulo tkinter per creare interfacce grafiche
from tkinter import messagebox, simpledialog  # Importa messagebox e simpledialog da tkinter per dialoghi

class StudentClient:  # Definisce una classe per gestire le funzionalità del client studente
    def __init__(self, server_host='localhost', server_port=10001):  # Inizializza il client con host e porta
        self.server_host = server_host  # Salva l'host del server
        self.server_port = server_port  # Salva la porta del server
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Crea un socket TCP/IP

    def connect_to_server(self):  # Metodo per connettersi al server
        try:
            self.client_socket.connect((self.server_host, self.server_port))  # Tenta di connettersi al server
            print("Connected to the Segretary Server.")  # Stampa un messaggio di successo se la connessione è riuscita
        except ConnectionRefusedError:  # Gestisce l'errore se la connessione fallisce
            print("Failed to connect to the Segretary Server.")  # Stampa un messaggio di errore
            exit()  # Esce dal programma

    def book_exam(self, student_id, exam_name, date):  # Metodo per prenotare un esame
        request = {'type': 'book_exam', 'student_id': student_id, 'exam_name': exam_name, 'date': date}  # Crea la richiesta
        self.client_socket.sendall(json.dumps(request).encode('utf-8'))  # Invia la richiesta serializzata in JSON
        response = self.client_socket.recv(1024).decode('utf-8')  # Riceve la risposta dal server
        return json.loads(response)  # Deserializza la risposta da JSON e la restituisce

    def get_exam_dates(self, exam_name):  # Metodo per ottenere le date disponibili per un esame
        request = {'type': 'get_exam_dates', 'exam_name': exam_name}  # Crea la richiesta
        self.client_socket.sendall(json.dumps(request).encode('utf-8'))  # Invia la richiesta serializzata in JSON
        response = self.client_socket.recv(1024).decode('utf-8')  # Riceve la risposta dal server
        return json.loads(response)  # Deserializza la risposta da JSON e la restituisce

    def close_connection(self):  # Metodo per chiudere la connessione con il server
        self.client_socket.close()  # Chiude il socket

class StudentGUI:  # Definisce una classe per l'interfaccia grafica dello studente
    def __init__(self, student_client):  # Inizializza l'interfaccia grafica con il client studente
        self.student_client = student_client  # Salva il client studente
        self.root = tk.Tk()  # Crea la finestra principale
        self.root.title("Student Interface")  # Imposta il titolo della finestra

        self.student_id_entry = tk.Entry(self.root)  # Crea un campo di inserimento per l'ID studente
        # self.student_id_entry.pack()  # Aggiunge il campo di inserimento alla finestra (commentato qui)

        tk.Button(self.root, text="Book Exam", command=self.book_exam).pack()  # Crea e aggiunge un pulsante per prenotare un esame
        tk.Button(self.root, text="Show Available Exam Dates", command=self.show_available_exam_dates).pack()  # Crea e aggiunge un pulsante per mostrare le date disponibili

    def book_exam(self):  # Metodo chiamato quando si preme il pulsante per prenotare un esame
        student_id = simpledialog.askstring("Input", "Student ID:", parent=self.root)  # Chiede l'ID dello studente
        exam_name = simpledialog.askstring("Input", "Exam Name:", parent=self.root)  # Chiede il nome dell'esame
        date = simpledialog.askstring("Input", "Exam Date (YYYY-MM-DD):", parent=self.root)  # Chiede la data dell'esame
        response = self.student_client.book_exam(student_id, exam_name, date)  # Invia la richiesta di prenotazione
        messagebox.showinfo("Response", response.get('success', response.get('error', 'Unknown error')))  # Mostra la risposta

    def show_available_exam_dates(self):  # Metodo chiamato quando si preme il pulsante per visualizzare le date disponibili
        exam_name = simpledialog.askstring("Input", "Exam Name:", parent=self.root)  # Chiede il nome dell'esame
        response = self.student_client.get_exam_dates(exam_name)  # Invia la richiesta per ottenere le date
        if 'dates' in response and response['dates']:  # Se ci sono date disponibili
            messagebox.showinfo("Available Dates", "\n".join(response['dates']))  # Mostra le date
        else:  # Se non ci sono date disponibili o c'è stato un errore
            messagebox.showinfo("Available Dates", response.get('error', 'No dates available or exam does not exist'))  # Mostra un messaggio di errore

    def run(self):  # Metodo per avviare l'interfaccia grafica
        self.root.mainloop()  # Avvia il ciclo principale dell'interfaccia grafica

if __name__ == "__main__":  # Se lo script viene eseguito direttamente
    student_client = StudentClient()  # Crea un'istanza del client studente
    student_client.connect_to_server()  # Si connette al server
    gui = StudentGUI(student_client)  # Crea un'istanza dell'interfaccia grafica
    gui.run()  # Avvia l'interfaccia grafica
